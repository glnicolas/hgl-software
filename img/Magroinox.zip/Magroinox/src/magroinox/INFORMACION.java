package magroinox;

import java.awt.Image;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class INFORMACION extends javax.swing.JFrame {

    String rutaImagen = "";

    public INFORMACION() {
        initComponents();
        this.setLocationRelativeTo(null);

        ImageIcon imagen = new ImageIcon(getClass().getResource("/imagenes/logo-posting.png"));
        ImageIcon imagen2 = new ImageIcon(imagen.getImage().getScaledInstance(p1.getWidth(), p1.getHeight(), Image.SCALE_DEFAULT));
        p1.setIcon(imagen2);

        // conexion con = new conexion ();
        //Codigo.setText("insert into Inventario (  codigo ) VALUES ("+codigo+")");
        Coneccion con = new Coneccion();
        con.establecerConeccion();
        try {
            ResultSet Rs = con.getTabla("SELECT MAX(Codigo) AS Codigo FROM Inventario");
            Rs.next();
            int cod = Rs.getInt("Codigo");
            cod++;
            Codigo.setText(cod + "");
        } catch (SQLException e) {
            System.out.println("Error al establecer el código.");
        }
        con.cerrarConexion();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        p1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        Codigo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        Nombre = new javax.swing.JTextField();
        fotos = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Descripcion = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        Precio = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        Cantidad = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        p2 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        foto = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        Buscar = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        p1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        getContentPane().add(p1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 310, 140));

        jLabel1.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel1.setText("Codigo");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 160, 30));

        Codigo.setEditable(false);
        Codigo.setBackground(new java.awt.Color(51, 255, 255));
        Codigo.setForeground(new java.awt.Color(0, 0, 153));
        Codigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CodigoActionPerformed(evt);
            }
        });
        Codigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CodigoKeyPressed(evt);
            }
        });
        getContentPane().add(Codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 260, 50));

        jLabel2.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel2.setText("Nombre del Producto");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 450, 380, 30));

        Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreActionPerformed(evt);
            }
        });
        Nombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                NombreKeyPressed(evt);
            }
        });
        getContentPane().add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 490, 610, 60));

        fotos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        getContentPane().add(fotos, new org.netbeans.lib.awtextra.AbsoluteConstraints(1046, 190, 310, 410));

        jLabel5.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel5.setText("Descripcion del Producto");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 580, 450, 40));

        Descripcion.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        Descripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DescripcionActionPerformed(evt);
            }
        });
        Descripcion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                DescripcionKeyPressed(evt);
            }
        });
        getContentPane().add(Descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 640, 750, 60));

        jLabel6.setFont(new java.awt.Font("Dialog", 3, 36)); // NOI18N
        jLabel6.setText("Precio Unitario");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 240, 260, 40));

        Precio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                PrecioKeyPressed(evt);
            }
        });
        getContentPane().add(Precio, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 290, 320, 50));

        jLabel7.setFont(new java.awt.Font("Dialog", 3, 30)); // NOI18N
        jLabel7.setText("Cantidad de Producto");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 240, 320, 40));

        Cantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                CantidadKeyPressed(evt);
            }
        });
        getContentPane().add(Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 290, 340, 50));

        jButton1.setFont(new java.awt.Font("Dialog", 2, 18)); // NOI18N
        jButton1.setText("Salir");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 40, 150, 50));

        jButton2.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        jButton2.setText("Modificar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 50, 130, 50));

        p2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/save_all.png"))); // NOI18N
        p2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p2ActionPerformed(evt);
            }
        });
        p2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                p2KeyPressed(evt);
            }
        });
        getContentPane().add(p2, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 410, 180, 190));

        jLabel8.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jLabel8AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 230, 60, 50));

        jLabel9.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jLabel9AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 240, 70, 50));

        jLabel10.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jLabel10AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 240, 70, 50));
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 230, -1, 30));

        jLabel12.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jLabel12AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 430, 70, 60));

        jLabel13.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jLabel13AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 570, 70, 50));

        foto.setFont(new java.awt.Font("Dialog", 2, 18)); // NOI18N
        foto.setText("Foto");
        foto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                fotoMouseClicked(evt);
            }
        });
        foto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fotoActionPerformed(evt);
            }
        });
        getContentPane().add(foto, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 120, 150, 50));

        jLabel3.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jLabel3AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 60, 60, 60));
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 740, -1, -1));
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(1330, 120, 40, -1));

        Buscar.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarActionPerformed(evt);
            }
        });
        Buscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                BuscarKeyReleased(evt);
            }
        });
        getContentPane().add(Buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 60, 470, 60));

        jButton3.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jButton3.setText("Eliminar ");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 620, 170, 60));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
//     System.exit(0);
        menu men = new menu();
        men.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_jButton1ActionPerformed

    private void p2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p2ActionPerformed

        Coneccion c = new Coneccion();
        c.establecerConeccion();

//        Image foto = ImageIO.read("C:\\Users\\oscar\\Pictures\\Nueva carpeta\\kit.PNG");
        ImageIcon imagen = new ImageIcon(foto.getText());

//        c.insertProducto(Integer.parseInt(Codigo.getText()), Double.parseDouble(Precio.getText()),Integer.parseInt(Cantidad.getText()), Nombre.getText(), Descripcion.getText(), imagen.getImage() );
        c.insertProducto(Double.parseDouble(Precio.getText()), Integer.parseInt(Cantidad.getText()), Nombre.getText(), Descripcion.getText(), rutaImagen);

        /* Precio.setText(null);
        Cantidad.setText(null);
        Nombre.setText(null);
        Descripcion.setText(null);*/
        //rutaImagen.split(null);
        INFORMACION inf = new INFORMACION();
        inf.setVisible(true);
        this.dispose();


    }//GEN-LAST:event_p2ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
                 
    }//GEN-LAST:event_jButton2ActionPerformed

    private void CodigoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CodigoKeyPressed

    }//GEN-LAST:event_CodigoKeyPressed

    private void PrecioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PrecioKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            Cantidad.requestFocus();
        }
    }//GEN-LAST:event_PrecioKeyPressed

    private void CantidadKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CantidadKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            Nombre.requestFocus();
        }
    }//GEN-LAST:event_CantidadKeyPressed

    private void NombreKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_NombreKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            Descripcion.requestFocus();
        }
    }//GEN-LAST:event_NombreKeyPressed

    private void jLabel8AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jLabel8AncestorAdded
        ImageIcon imagen = new ImageIcon(getClass().getResource("/imagenes/codigo.png"));
        ImageIcon imagen4 = new ImageIcon(imagen.getImage().getScaledInstance(jLabel8.getWidth(), jLabel8.getHeight(), Image.SCALE_DEFAULT));
        jLabel8.setIcon(imagen4);
    }//GEN-LAST:event_jLabel8AncestorAdded

    private void jLabel9AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jLabel9AncestorAdded
        ImageIcon imagen = new ImageIcon(getClass().getResource("/imagenes/precio.png"));
        ImageIcon imagen5 = new ImageIcon(imagen.getImage().getScaledInstance(jLabel9.getWidth(), jLabel9.getHeight(), Image.SCALE_DEFAULT));
        jLabel9.setIcon(imagen5);
    }//GEN-LAST:event_jLabel9AncestorAdded

    private void jLabel10AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jLabel10AncestorAdded
        ImageIcon imagen = new ImageIcon(getClass().getResource("/imagenes/cantidad.png"));
        ImageIcon imagen6 = new ImageIcon(imagen.getImage().getScaledInstance(jLabel10.getWidth(), jLabel10.getHeight(), Image.SCALE_DEFAULT));
        jLabel10.setIcon(imagen6);
    }//GEN-LAST:event_jLabel10AncestorAdded

    private void jLabel12AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jLabel12AncestorAdded
        ImageIcon imagen = new ImageIcon(getClass().getResource("/imagenes/nombre.png"));
        ImageIcon imagen7 = new ImageIcon(imagen.getImage().getScaledInstance(jLabel12.getWidth(), jLabel12.getHeight(), Image.SCALE_DEFAULT));
        jLabel12.setIcon(imagen7);
    }//GEN-LAST:event_jLabel12AncestorAdded

    private void jLabel13AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jLabel13AncestorAdded
        ImageIcon imagen = new ImageIcon(getClass().getResource("/imagenes/infor.png"));
        ImageIcon imagen8 = new ImageIcon(imagen.getImage().getScaledInstance(jLabel13.getWidth(), jLabel13.getHeight(), Image.SCALE_DEFAULT));
        jLabel13.setIcon(imagen8);
    }//GEN-LAST:event_jLabel13AncestorAdded

    private void CodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CodigoActionPerformed

    private void DescripcionKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_DescripcionKeyPressed
        char Teclado = evt.getKeyChar();
        if (Teclado == KeyEvent.VK_ENTER) {
            foto.doClick();

        }
    }//GEN-LAST:event_DescripcionKeyPressed

    private void p2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_p2KeyPressed
        ImageIcon imagen = new ImageIcon(getClass().getResource("/imagenes/images.png"));
        ImageIcon imagen3 = new ImageIcon(imagen.getImage().getScaledInstance(p2.getWidth(), p2.getHeight(), Image.SCALE_DEFAULT));
        p2.setIcon(imagen3);
        //conect.insertProducto(Codigo.getText());


    }//GEN-LAST:event_p2KeyPressed

    private void NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreActionPerformed

    private void fotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fotoActionPerformed
        JFileChooser j = new JFileChooser();
        FileNameExtensionFilter fil = new FileNameExtensionFilter("JPG, PNG & GIF", "jpg", "png", "gif");
        j.setFileFilter(fil);

        int s = j.showOpenDialog(this);
        if (s == JFileChooser.APPROVE_OPTION) {
            String ruta = j.getSelectedFile().getAbsolutePath();
//            fotos.setText(ruta);
//            ImageIcon imagen = new ImageIcon("C:\\Users\\oscar\\Pictures\\Nueva carpeta\\kit.PNG");
            ImageIcon imagen = new ImageIcon(ruta);
            ImageIcon imagen2 = new ImageIcon(imagen.getImage().getScaledInstance(fotos.getWidth(), fotos.getHeight(), Image.SCALE_DEFAULT));
            rutaImagen = ruta;
            fotos.setIcon(imagen2);

        }
    }//GEN-LAST:event_fotoActionPerformed

    private void jLabel3AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jLabel3AncestorAdded
        ImageIcon imagen = new ImageIcon(getClass().getResource("/imagenes/buscar.png"));
        ImageIcon image = new ImageIcon(imagen.getImage().getScaledInstance(jLabel3.getWidth(), jLabel3.getHeight(), Image.SCALE_DEFAULT));
        jLabel3.setIcon(image);
    }//GEN-LAST:event_jLabel3AncestorAdded

    private void fotoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fotoMouseClicked

    }//GEN-LAST:event_fotoMouseClicked

    private void DescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DescripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DescripcionActionPerformed

    private void BuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_BuscarKeyReleased
      // String pantalla = Buscar.getText() + "%";
      // String sql = "sect"
       
    }//GEN-LAST:event_BuscarKeyReleased

    private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BuscarActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        Coneccion con = new Coneccion();
        String info = "delate from Inventario where codigo = ?; ";
        
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(INFORMACION.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(INFORMACION.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(INFORMACION.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(INFORMACION.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                INFORMACION.conectar();
                new INFORMACION().setVisible(true);
            }
        });
    }

    static Coneccion conect;

    public static void conectar() {
        conect = new Coneccion();
        conect.establecerConeccion();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Buscar;
    private javax.swing.JTextField Cantidad;
    private javax.swing.JTextField Codigo;
    private javax.swing.JTextField Descripcion;
    private javax.swing.JTextField Nombre;
    private javax.swing.JTextField Precio;
    private javax.swing.JButton foto;
    private javax.swing.JLabel fotos;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel p1;
    private javax.swing.JButton p2;
    // End of variables declaration//GEN-END:variables
}
