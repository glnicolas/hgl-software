
package magroinox;

import java.awt.Image;
import java.io.FileInputStream;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


/**
 *
 * @author oscar
 */
public class Coneccion {

//    private static Connection Connection() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    Connection conect = null;
    

    public void establecerConeccion() {
//        String url = "jdbc:sqlserver://localhost:1433;databaseName=Examen;integratedSecurity=true";
        String url = "jdbc:sqlserver://;databaseName=Magroinox;integratedSecurity=true";
        try {
            conect = DriverManager.getConnection(url);
            //JOptionPane.showMessageDialog(null, "Conección exitosa a base de dato");
            System.out.println("Conección exitosa a base de dato");
            
        } catch (SQLException e) {
            
            //JOptionPane.showMessageDialog(null, "Error al conectar base de datos","Alerta",JOptionPane.WARNING_MESSAGE);
            System.out.println("Error al conectar base de datos" + "Alerta" + JOptionPane.WARNING_MESSAGE);
            
        }
    }
    
    

    
    
    
    public void insertProducto(double precio, int cantidad, String nombre, String Descripcion, String foto)
    {
        try
        {
            Statement st = conect.createStatement();
            
            st.execute("insert into Inventario ( PrecioUnitario, Cantidad, Nombre, Descripcion, foto) VALUES ("+precio+", "+cantidad+", '"+nombre+"', '"+Descripcion+"', '"+foto+"')");
             /*st.execute("insert into Inventario (codigo, PrecioUnitario, Cantidad, Nombre, Descripcion) VALUES ("+codigo+", "+precio+", "+cantidad+", '"+nombre+"', '"+Descripcion+"')");
            */
            //JOptionPane.showMessageDialog(null, "Inserción exitosa");
            System.out.println("Inserción exitosa");
        }
        catch(SQLException e)
        {
            System.out.println("Error al introducir prodcutos: " + e.getMessage());
        }
    }
    
    public ResultSet getTabla (String Consulta){
       Statement st;
       ResultSet datos = null;
       try{
           st = conect.createStatement();
           datos = st.executeQuery(Consulta);
       }
       catch(Exception e){System.out.println(e.toString());}
       return datos;
       
        
}
    
    public void cerrarConexion()
    {
        try
        {
            conect.close();
        }
        catch(SQLException e)
        {
            System.out.println("Error al cerrar conexión.");
        }
    }

    
    
}
